import api from './client';
import type {
  Video, FolderTree, ServerStats, VideoHealth, FolderHealth, RepairJob, RepairPlan,
} from '../types';

export interface PreviewMeta {
  count: number;
  interval: number;
  tileW: number;
  tileH: number;
  frameBase: string; // append `${index}.jpg`
}
export interface PreviewReady extends PreviewMeta {
  status: 'ready';
}
// While generating we now also return the layout + frameBase so the client can
// show frames the instant each one lands on disk (progressive), not all-or-nothing.
export interface PreviewGenerating extends PreviewMeta {
  status: 'generating';
  progress: number;
}
export type PreviewResponse =
  | PreviewReady
  | PreviewGenerating
  | { status: 'error' };

export const previewApi = {
  get: (id: string) => api.get<PreviewResponse>(`/preview/${id}`).then(r => r.data),
  remove: (id: string) => api.delete(`/preview/${id}`).then(r => r.data).catch(() => {}),
};

/** Outcome of a bulk move — a name clash used to look like nothing happened. */
export interface MoveResult {
  ok: boolean;
  moved: number;
  alreadyThere: number;
  /** Ids the server no longer knows — the library view was stale. */
  missing: number;
  conflicts: string[];
  failed: string[];
}

export interface DeleteResult {
  ok: boolean;
  deleted: number;
  missing: number;
  failed: string[];
}

export const videosApi = {
  list: (folder = '', all = false, deep = true) =>
    api.get<Video[]>('/videos', {
      params: { folder, ...(all && { all: '1' }), ...(deep ? {} : { deep: '0' }) },
    }).then(r => r.data),

  info: (id: string) => api.get<Video>(`/videos/${id}/info`).then(r => r.data),

  tree: () => api.get<FolderTree>('/tree').then(r => r.data),

  allFolders: () => api.get<string[]>('/folders/all').then(r => r.data),

  stats: () => api.get<ServerStats>('/stats').then(r => r.data),

  rescan: () => api.post('/rescan').then(r => r.data),

  rename: (id: string, name: string) =>
    api.patch(`/videos/${id}`, { name }).then(r => r.data),

  delete: (ids: string[]) =>
    api.delete<DeleteResult>('/videos', { data: { ids } }).then(r => r.data),

  move: (ids: string[], folder: string) =>
    api.post<MoveResult>('/videos/move', { ids, folder }).then(r => r.data),

  createFolder: (name: string, parent = '') =>
    api.post<{ ok: boolean; folder: string }>('/folders', { name, parent }).then(r => r.data),

  renameFolder: (folder: string, name: string) =>
    api.patch('/folders', { folder, name }).then(r => r.data),

  deleteFolder: (folder: string) =>
    api.delete('/folders', { data: { folder } }).then(r => r.data),

  moveFolder: (folder: string, dest: string) =>
    api.post('/folders/move', { folder, dest }).then(r => r.data),

  archiveFolders: () =>
    api.get<string[]>('/folders/archives').then(r => r.data),
};

// ── Favourites ────────────────────────────────────────────────────────────────

export const favoritesApi = {
  list: () => api.get<Video[]>('/favorites').then(r => r.data),

  /** Omit `favorite` to flip whatever the server currently has. */
  set: (id: string, favorite?: boolean) =>
    api.post<{ ok: boolean; favorite: boolean }>(
      `/videos/${id}/favorite`, favorite === undefined ? {} : { favorite },
    ).then(r => r.data),
};

// ── Repair ────────────────────────────────────────────────────────────────────

export const repairApi = {
  health: (id: string) => api.get<VideoHealth>(`/videos/${id}/health`).then(r => r.data),

  folderHealth: (folder: string, deep = true) =>
    api.get<FolderHealth>('/folders/health', {
      params: { folder, ...(deep ? {} : { deep: '0' }) },
    }).then(r => r.data),

  start: (id: string, plan?: RepairPlan) =>
    api.post<RepairJob>(`/videos/${id}/repair`, plan ? { plan } : {}).then(r => r.data),

  startFolder: (folder: string, deep = true) =>
    api.post<{ ok: boolean; queued: number; jobs: RepairJob[] }>(
      '/repair/folder', { folder, deep },
    ).then(r => r.data),

  jobs: () => api.get<RepairJob[]>('/repair').then(r => r.data),

  cancel: (jobId: string) => api.post(`/repair/${jobId}/cancel`).then(r => r.data),
};
