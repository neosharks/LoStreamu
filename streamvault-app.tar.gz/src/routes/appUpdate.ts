import { Router } from 'express';
import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';
import type { Response } from 'express';
import { requireAuth } from '../middleware/auth';
import { APP_DIR, DATA_DIR, DENO_DIR, DENO_LOCAL, getConfig } from '../config';

const router = Router();

let _updating = false;

function sseLog(res: Response, msg: string, type: 'log' | 'error' | 'done' = 'log') {
  try { res.write(`event: ${type}\ndata: ${JSON.stringify({ msg })}\n\n`); } catch {}
}

// npm writes logs/cache to $HOME — the streamvault service user's home dir may
// not have a writable .npm directory, causing exit code 243. Point npm at /tmp.
const NPM_ENV = {
  ...process.env,
  HOME: '/tmp',
  npm_config_cache: '/tmp/.npm-sv',
  npm_config_fund: 'false',
  npm_config_audit: 'false',
  npm_config_update_notifier: 'false',
};

function runStep(cmd: string, args: string[], cwd: string, res: Response): Promise<void> {
  return new Promise((resolve, reject) => {
    const env = cmd === 'npm' ? NPM_ENV : process.env;
    const proc = spawn(cmd, args, { cwd, stdio: ['ignore', 'pipe', 'pipe'], env });
    proc.on('error', reject);
    proc.stdout.on('data', (d: Buffer) => {
      for (const line of d.toString().split('\n')) {
        if (line.trim()) sseLog(res, line.trim());
      }
    });
    proc.stderr.on('data', (d: Buffer) => {
      for (const line of d.toString().split('\n')) {
        if (line.trim()) sseLog(res, line.trim());
      }
    });
    proc.on('close', (code: number | null) => code === 0 ? resolve() : reject(new Error(`${cmd} exited with code ${code}`)));
  });
}

router.get('/app/update/stream', requireAuth, async (req, res) => {
  if (_updating) {
    res.status(409).json({ error: 'Update already in progress' });
    return;
  }
  _updating = true;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const log = (msg: string) => sseLog(res, msg);
  const clientDir = path.join(APP_DIR, 'client');
  const tarPath = '/tmp/sv-update.tar.gz';
  const updateUrl = getConfig().updateUrl ||
    'https://raw.githubusercontent.com/neosharks/LoStreamu/main/streamvault-app.tar.gz';

  try {
    log(`► Downloading latest release from GitHub...`);
    await runStep('curl', ['-fL', '--retry', '3', '-o', tarPath, updateUrl], '/tmp', res);
    log(`✓ Downloaded`);

    log(`► Extracting archive...`);
    const stage = '/tmp/sv-update-stage';
    fs.rmSync(stage, { recursive: true, force: true });
    fs.mkdirSync(stage, { recursive: true });
    await runStep('tar', ['-xzf', tarPath, '-C', stage], '/', res);
    fs.rmSync(tarPath, { force: true });
    log(`✓ Extracted`);

    // tar only ever adds files. Unpacking straight over the app directory leaves
    // behind any source file a release deleted — and one stale file that still
    // imports something removed is enough to fail the build. Mirror the release
    // instead, protecting everything below, which is live data rather than code.
    log(`► Syncing app files...`);
    try {
      await runStep('rsync', ['-a', '--delete',
        '--exclude=node_modules/', '--exclude=dist/',
        '--exclude=client/node_modules/', '--exclude=client/dist/',
        '--exclude=config.json', '--exclude=secrets.json',
        '--exclude=users.json', '--exclude=users.json.password-era.bak',
        '--exclude=meta-cache.json', '--exclude=download-queue.json',
        '--exclude=/favorites.json',
        '--exclude=cookies.txt', '--exclude=yt-dlp', '--exclude=server.log',
        '--exclude=media/', '--exclude=thumbnails/', '--exclude=previews/',
        '--exclude=/deno/',
        `${stage}/`, `${APP_DIR}/`,
      ], '/', res);
      log(`✓ Synced`);
    } catch {
      // No rsync on this box — fall back to the old copy-over behaviour rather
      // than abandoning the update.
      log(`  (rsync unavailable — copying without pruning removed files)`);
      await runStep('cp', ['-a', `${stage}/.`, APP_DIR], '/', res);
    }
    fs.rmSync(stage, { recursive: true, force: true });

    // tar only adds files, so code deleted upstream survives in dist/. The
    // password-era CLI is the one that matters: it would still run and write
    // dead credential fields back into config.json.
    const staleCli = path.join(APP_DIR, 'dist', 'cli');
    if (fs.existsSync(staleCli)) {
      fs.rmSync(staleCli, { recursive: true, force: true });
      log(`✓ Removed superseded dist/cli`);
    }

    log(`► Ensuring Chromium is installed...`);
    try {
      await runStep('sudo', ['apt-get', 'install', '-y', '--no-install-recommends', 'chromium'], '/', res);
      log(`✓ Chromium ready`);
    } catch {
      log(`  (skipped — sudo not available, Chromium may already be installed)`);
    }

    log(`► Ensuring curl-cffi is installed (yt-dlp TLS impersonation)...`);
    try {
      await runStep('pip3', ['install', '-q', '--break-system-packages', 'curl-cffi'], '/', res);
      log(`✓ curl-cffi ready`);
    } catch {
      try {
        await runStep('pip3', ['install', '-q', 'curl-cffi'], '/', res);
        log(`✓ curl-cffi ready`);
      } catch {
        log(`  (skipped — curl-cffi install failed, --impersonate may not work)`);
      }
    }

    // YouTube downloads need a JS runtime. Without root the system deno that
    // install-lxc.sh sets up may be missing, so install a private copy.
    log(`► Ensuring deno is available (yt-dlp YouTube JS runtime)...`);
    try {
      await runStep('sh', ['-c',
        `command -v deno || [ -x "${DENO_LOCAL}" ] || ` +
        `curl -fsSL https://deno.land/install.sh | DENO_INSTALL="${DENO_DIR}" sh -s -- -y --no-modify-path`,
      ], '/', res);
      log(`✓ deno ready`);
    } catch {
      log(`  (skipped — deno install failed, some YouTube downloads may fail)`);
    }

    log(`► Installing server dependencies...`);
    await runStep('npm', ['install', '--no-fund', '--no-audit', '--loglevel=error'], APP_DIR, res);
    log(`✓ Server deps installed`);

    // Client first. A failed client build must not leave a freshly compiled
    // server sitting next to a stale frontend — the next restart would then run
    // new server code against a UI that does not match it.
    if (fs.existsSync(clientDir)) {
      log(`► Installing client dependencies...`);
      await runStep('npm', ['install', '--no-fund', '--no-audit', '--loglevel=error'], clientDir, res);
      log(`✓ Client deps installed`);

      log(`► Building client (React/Vite)...`);
      await runStep('npm', ['run', 'build'], clientDir, res);
      log(`✓ Client built`);

      log(`► Cleaning client node_modules...`);
      fs.rmSync(path.join(clientDir, 'node_modules'), { recursive: true, force: true });
      log(`✓ Cleaned`);
    }

    log(`► Building server (TypeScript)...`);
    await runStep('npm', ['run', 'build:server'], APP_DIR, res);
    log(`✓ Server built`);

    log(`► Pruning dev dependencies...`);
    await runStep('npm', ['prune', '--production', '--no-fund', '--loglevel=error'], APP_DIR, res);
    log(`✓ Pruned`);

    // The updater runs unprivileged: it can replace the app but cannot install
    // the systemd unit that points the server at /var/lib/streamvault. Say so,
    // rather than leaving the separation silently half-applied.
    if (DATA_DIR === APP_DIR) {
      log(``);
      log(`ℹ Your videos and settings still live inside ${APP_DIR}.`);
      log(`  To move them to /var/lib/streamvault — where reinstalling the app`);
      log(`  cannot touch them — run this once on the Proxmox host:`);
      log(`    pct exec <CTID> -- bash /opt/streamvault/install-lxc.sh`);
      log(`  The server migrates the files itself on the next start.`);
    }

    sseLog(res, 'Update complete — restarting service in 2 seconds…', 'done');

    // Exit non-zero so systemd's Restart=on-failure triggers a clean restart
    // with the newly compiled code. The service user cannot call systemctl directly.
    setTimeout(() => process.exit(1), 2000);
  } catch (err: any) {
    sseLog(res, `✗ ${err.message}`, 'error');
  } finally {
    _updating = false;
  }
});

export default router;
