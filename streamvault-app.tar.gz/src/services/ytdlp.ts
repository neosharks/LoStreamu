import { execFile, spawn, spawnSync } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { getProxy, COOKIES_PATH, YT_DLP_LOCAL, DENO_LOCAL } from '../config';
import { fetchCookiesViaBrowser } from './browserCookies';
import type { PlaylistProbeResult, PlaylistEntry, YtDlpVersionInfo } from '../types';

const execFileP = promisify(execFile);

export function ytDlpBin(): string {
  return fs.existsSync(YT_DLP_LOCAL) ? YT_DLP_LOCAL : 'yt-dlp';
}

export function normalizeUrl(url: string): string {
  return url;
}


// First yt-dlp release with --js-runtimes (YouTube's EJS challenge solver).
const JS_RUNTIMES_SINCE = '2025.11.12';
// Oldest Node yt-dlp accepts as a JS runtime.
const MIN_NODE_FOR_YTDLP = 22;

// True if `--list-impersonate-targets` output has a usable Chrome target.
// yt-dlp still lists targets whose backend is missing, suffixed "(unavailable)".
export function hasChromeImpersonation(listing: string): boolean {
  return listing.split('\n').some(l => /^chrome\b/i.test(l.trim()) && !/unavailable/i.test(l));
}

// True if this yt-dlp version understands --js-runtimes. Versions are dated
// (YYYY.MM.DD[.build]), so string order is chronological.
export function supportsJsRuntimes(version: string): boolean {
  const m = version.match(/\d{4}\.\d{2}\.\d{2}/);
  return !!m && m[0] >= JS_RUNTIMES_SINCE;
}

interface YtDlpCaps { bin: string; impersonate: boolean; jsRuntimes: boolean }
let _caps: YtDlpCaps | null = null;

// What the installed yt-dlp can use on this host. Passing a flag it can't honour
// is fatal: `--impersonate chrome` without a compatible curl-cffi aborts every
// run, and an unknown option fails argument parsing. Probed once per binary.
function ytDlpCaps(): YtDlpCaps {
  const bin = ytDlpBin();
  if (_caps?.bin === bin) return _caps;
  const r = spawnSync(bin, ['-v', '--list-impersonate-targets'], { encoding: 'utf8', timeout: 30000 });
  const version = (r.stderr || '').match(/yt-dlp version \S*?(\d{4}\.\d{2}\.\d{2}\S*)/)?.[1] || '';
  _caps = {
    bin,
    impersonate: hasChromeImpersonation(r.stdout || ''),
    jsRuntimes: supportsJsRuntimes(version),
  };
  if (!_caps.impersonate) {
    console.warn('[ytdlp] Chrome impersonation unavailable (curl-cffi missing or unsupported) — downloading without it');
  }
  return _caps;
}

export function ytNetArgs(): string[] {
  const caps = ytDlpCaps();
  const args: string[] = [];
  if (fs.existsSync(COOKIES_PATH)) args.push('--cookies', COOKIES_PATH);
  const proxy = getProxy();
  if (proxy) args.push('--proxy', proxy);
  // Impersonate Chrome at the TLS + HTTP level — fixes connection-reset-by-peer
  // on sites that fingerprint the TLS handshake (requires curl-cffi on server).
  if (caps.impersonate) args.push('--impersonate', 'chrome');
  // YouTube needs a JS runtime to solve its player challenges; without one,
  // formats go missing or extraction fails. yt-dlp only finds deno on PATH by
  // default, so also offer the updater's own deno and, when new enough, the
  // Node running this app.
  if (caps.jsRuntimes) {
    if (fs.existsSync(DENO_LOCAL)) args.push('--js-runtimes', `deno:${DENO_LOCAL}`);
    if (Number(process.versions.node.split('.')[0]) >= MIN_NODE_FOR_YTDLP) {
      args.push('--js-runtimes', `node:${process.execPath}`);
    }
  }
  args.push(
    '--add-header', 'Accept-Language:en-US,en;q=0.9',
    '--force-ipv4',
    '--geo-bypass',
    '--retries', '10',
    '--fragment-retries', '10',
    '--socket-timeout', '30',
    '--extractor-retries', '5',
    '--sleep-requests', '2',
    '--no-check-certificates',
  );
  return args;
}

// Speed flags for actual media downloads (NOT metadata probes).
// - concurrent-fragments: parallelise DASH/HLS chunk fetches (the #1 throughput win)
// - http-chunk-size: chunked HTTP sidesteps YouTube's single-connection throttling
// Both are network-bound — negligible CPU, so they don't undo the CPU work above.
export function ytSpeedArgs(): string[] {
  return ['--concurrent-fragments', '4', '--http-chunk-size', '10M'];
}

// Format selection + container flags shared by every media download.
//
// Why this shape: a self-hosted library is watched from every browser (incl.
// Safari / iOS), so the file on disk must be broadly playable WITHOUT re-encoding
// (this app runs on tiny low-CPU boxes). We therefore:
//   • prefer an MP4 (H.264 video + AAC audio) stream when the site offers one —
//     the one combo every browser plays — via the `-f` preference ladder AND the
//     `-S` format sort (vcodec:h264 / acodec:aac). VP9/AV1/Opus are the fallback,
//     not the default, so we don't hand Safari a file it can't decode;
//   • always land in an MP4 container (`--merge-output-format` + `--remux-video`);
//   • move the moov atom to the front (`+faststart`) so the file streams and seeks
//     from byte 0 instead of the player hunting for the index — the usual cause of
//     "it starts in the wrong place / jumps around" on progressive playback.
export function ytFormatArgs(): string[] {
  return [
    '-f',
    // avc1+m4a mp4 → any mp4 video+m4a → any progressive mp4 → best video+audio → best
    'bv*[vcodec^=avc1][ext=mp4]+ba[ext=m4a]/bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b',
    '-S', 'vcodec:h264,acodec:aac,ext:mp4',
    '--merge-output-format', 'mp4',
    '--remux-video', 'mp4',
    // Move the MP4 index (moov) to the front so the file streams/plays immediately
    // instead of needing a full download first.
    '--postprocessor-args', 'ffmpeg:-movflags +faststart',
  ];
}

// Minimum video length to download. Anything shorter is skipped by yt-dlp
// (it reads duration from metadata first and never downloads the media).
export const MIN_DURATION_SEC = 600; // 10 minutes

// True for YouTube URLs (any subdomain, plus youtu.be short links and the
// privacy-enhanced youtube-nocookie.com host). Malformed URLs → false.
export function isYouTubeUrl(url: string): boolean {
  try {
    const host = new URL(url).hostname.toLowerCase();
    return /(^|\.)youtube\.com$/.test(host)
      || /(^|\.)youtube-nocookie\.com$/.test(host)
      || host === 'youtu.be';
  } catch {
    return false;
  }
}

// yt-dlp filter that rejects videos under MIN_DURATION_SEC — EXCEPT for
// YouTube, where a video of any length is allowed. A rejected video makes
// yt-dlp print "does not pass filter" and exit 0 without downloading.
export function ytFilterArgs(url: string): string[] {
  if (isYouTubeUrl(url)) return [];
  return ['--match-filter', `duration >= ${MIN_DURATION_SEC}`];
}

// True if a yt-dlp output line indicates the video was skipped by the filter.
export function isFilteredOut(line: string): boolean {
  return /does not pass filter/i.test(line);
}

function decodeHtml(s: string): string {
  return String(s || '')
    .replace(/&#(\d+);/g, (_, n: string) => String.fromCharCode(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, h: string) => String.fromCharCode(parseInt(h, 16)))
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'");
}

export function netHint(msg: string): string {
  if (/impersonate target.*not available|missing dependencies required to support/i.test(msg))
    return msg + ' — yt-dlp is missing the curl-cffi dependency. Fix: pip3 install --break-system-packages curl-cffi';
  if (/HTTP Error 410|410.*Gone/i.test(msg))
    return msg + ' — Site rejected the request (410). Try updating yt-dlp via the navbar button.';
  if (/sign.?in|log.?in required|age.?verif|members.?only|premium|private|video.*not available|not available.*country|account required/i.test(msg))
    return msg + ' — Authentication required. Drop a cookies.txt (Netscape format) next to server.js and retry.';
  if (/reset by peer|errno 104|connection refused|timed out|network is unreachable|getaddrinfo|failed to resolve/i.test(msg))
    return msg + (getProxy()
      ? ' — Even via the configured proxy. Check the proxy can reach this site.'
      : ' — Site looks blocked on the server network. Set a proxy in Account → Network settings.');
  return msg;
}

// Returns true if the error looks like an age-gate / bot-detection rejection.
function isAgeGateError(err: unknown): boolean {
  const msg = (err instanceof Error ? err.message : String(err)).toLowerCase();
  // Exclude yt-dlp dependency/feature errors — these are not age gates.
  if (/impersonate target|missing dependencies required to support/i.test(msg)) return false;
  return /410|403 forbidden|age.?gate|age.?verif|video.*not available|not available.*country|confirm your age/i.test(msg);
}

// Run fn; on age-gate error fetch cookies via browser and retry once.
async function withAgeGateRetry<T>(url: string, fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    if (!isAgeGateError(err)) throw err;
    console.log(`[ytdlp] age-gate detected for ${url} — launching browser to accept…`);
    await fetchCookiesViaBrowser(url);
    return await fn();
  }
}

export async function fetchPlaylistEntries(url: string): Promise<PlaylistProbeResult> {
  const run = () => execFileP(ytDlpBin(), [
    '-J', '--flat-playlist', '--no-warnings', ...ytNetArgs(), normalizeUrl(url),
  ], { timeout: 60000, maxBuffer: 50 * 1024 * 1024 });

  const { stdout } = await withAgeGateRetry(url, run);

  const j = JSON.parse(stdout);
  const rawEntries: any[] = j.entries || [];
  const entries: PlaylistEntry[] = rawEntries.map((e: any, i: number) => ({
    index: i + 1,
    title: decodeHtml(e.title) || `Item ${i + 1}`,
    url: e.url || e.webpage_url,
    duration: e.duration,
    thumbnail: e.thumbnail || (e.thumbnails?.[0]?.url),
  }));

  return {
    title: decodeHtml(j.title || j.playlist_title || 'Playlist'),
    count: entries.length,
    entries,
  };
}

export async function fetchMeta(url: string): Promise<{ title: string; uploader?: string; thumbUrl?: string }> {
  const run = () => execFileP(ytDlpBin(), [
    '-J', '--no-playlist', '--no-warnings', ...ytNetArgs(), normalizeUrl(url),
  ], { timeout: 30000, maxBuffer: 10 * 1024 * 1024 });

  const { stdout } = await withAgeGateRetry(url, run);

  const j = JSON.parse(stdout);
  return {
    title: decodeHtml(j.title || j.fulltitle || ''),
    uploader: decodeHtml(j.uploader || j.channel || j.extractor_key || ''),
    thumbUrl: j.thumbnail || j.thumbnails?.[0]?.url,
  };
}

let _latestCache: { tag: string | null; at: number } = { tag: null, at: 0 };
const CACHE_TTL = 6 * 60 * 60 * 1000;

export async function getYtDlpVersion(): Promise<YtDlpVersionInfo> {
  let current: string | null = null;
  try {
    const { stdout } = await execFileP(ytDlpBin(), ['--version'], { timeout: 8000 });
    current = stdout.trim();
  } catch {}

  const now = Date.now();
  if (!_latestCache.tag || now - _latestCache.at > CACHE_TTL) {
    try {
      const res = await fetch('https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest', {
        headers: { 'User-Agent': 'streamvault/2.0' },
      });
      const data = await res.json() as { tag_name?: string };
      _latestCache = { tag: data.tag_name || null, at: now };
    } catch {}
  }

  const latest = _latestCache.tag;
  return { current, latest, outdated: !!(current && latest && current !== latest) };
}

export async function updateYtDlp(): Promise<void> {
  const tmp = YT_DLP_LOCAL + '.tmp';
  try {
    await execFileP('curl', [
      '-fsSL',
      'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp',
      '-o', tmp,
    ], { timeout: 120000 });
    fs.renameSync(tmp, YT_DLP_LOCAL);
    fs.chmodSync(YT_DLP_LOCAL, 0o755);
    try { fs.copyFileSync(YT_DLP_LOCAL, '/usr/local/bin/yt-dlp'); } catch {}
    _latestCache = { tag: null, at: 0 };
    _caps = null;
  } catch (err) {
    try { fs.rmSync(tmp, { force: true }); } catch {}
    throw err;
  }
}

export function spawnDownload(args: string[]) {
  const bin = ytDlpBin();
  // On Linux run the download at the lowest CPU priority so video streaming and
  // the web app always win under contention (playback is the priority). yt-dlp's
  // ffmpeg merge inherits the niceness. `nice` execs in place, so the returned
  // process is still yt-dlp and SIGTERM/kill work as before.
  if (process.platform === 'linux') {
    return spawn('nice', ['-n', '19', bin, ...args], { stdio: ['ignore', 'pipe', 'pipe'] });
  }
  return spawn(bin, args, { stdio: ['ignore', 'pipe', 'pipe'] });
}
